import pandas as pd
import re

# 로그 파일 경로 및 출력 파일 경로
log_file = "/home/dhlee/test_data/mysql_error_nvdimm.log"
output_file = "/home/dhlee/tool/7200s_33c_15cnt.csv"

# 패턴 정의
query_pattern = "User Query : "
data_pattern = "Current Space Id"
olap_query_pattern = "User Query : select"
log_pattern = r"Current Space Id:\s*(\d+), Page No:\s*(\d+), read_trx_id:\s*(\d+)\s*read_only:(\d+), read_write\s*:\s*(\d+),\s*thread_id\s*:\s*(\d+)"
data = []
# 매칭 여부 확인 함수
def is_matching_line(line, pattern):
    if re.match(pattern, line):
        return True
    else:
        return False

# 데이터프레임에 데이터 추가 함수
def df_data_append(is_olap, line):
    match = re.match(log_pattern, line)
    #print(f"{match} is matching line")
    if match:
        data.append({
            "olap": is_olap,
            "spaceid": int(match.group(1)),
            "pageno": int(match.group(2)),
            "trx_id": int(match.group(3)),
            "readonly": int(match.group(4)),
            "readwrite": int(match.group(5)),
            "threadid": int(match.group(6))
        })
        #print(f"{match.group(2)} data append")

# OLAP 상태 추적 변수
olap = False

try:
    with open(log_file, 'r', encoding='utf-8') as lines:
        for line in lines:
            # 'User Query : ' 패턴에 맞는 라인 확인
            if is_matching_line(line, query_pattern):
                if is_matching_line(line, olap_query_pattern):
                    #print(f"{line} olap match")
                    olap = True  # OLAP 쿼리 처리
                    continue
                else:
                    #print(f"{line} oltp match")
                    olap = False  # HTAP 쿼리 처리
                    continue

            # 'Space Id:' 패턴에 맞는 데이터 처리
            if is_matching_line(line, data_pattern):
                if olap:
                    # OLAP 데이터 처리
                    df_data_append(True, line)
                else:
                    # HTAP 데이터 처리
                    df_data_append(False, line)

    # DataFrame 생성 및 CSV 파일로 저장
    df = pd.DataFrame(data)
    df.to_csv(output_file, index=False)  # CSV 파일로 저장

    print(f"{output_file} make success")
except FileNotFoundError:
    print(f"Can't find {log_file}")
except Exception as e:
    print(f"Exception occurred: {str(e)}")

